
/* Rutina de suma */

extern int glb;

int suma(int x, int y)
{
  int aux;

  aux = x+y;

   printf("aux %d, %d\n", aux, glb);
  return aux;
}


#/** PhEDIT attribute block
#-11:16777215
#0:145:TextFont14:-3:-3:0
#**  PhEDIT attribute block ends (-0000115)**/
