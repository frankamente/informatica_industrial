/* Cabecera para una cola basada en variables compartidas */

  void pon_dato(int dato);
  void extrae_dato(int *dato);
