/* Cabecera */

#define LCOLA 5
#define N_MAX_ERR 5
#define ACTIVO 0
#define FIN       1