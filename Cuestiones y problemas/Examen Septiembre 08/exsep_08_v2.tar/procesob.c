/* Examen del 11/9/08: Proceso B (pruebas) */

#define _POSIX_C_SOURCE 199506L

#include <unistd.h>
#include <time.h>
#include <mqueue.h>
#include <signal.h>
#include <stdio.h>
#include <pthread.h>

#include "proceso.h"

/* Hilo de recepcion de senales */

void *recibe(void *p);

int main(int argc, char **argv)
{
   mqd_t cola;
   int n;
   struct timespec t = {0, 40000000L};
   int dato;
   sigset_t set;
   int espera [] = {40, 50, 80, 80, 8, 50, 80, 80, 50};
   //int espera [] = {40, 50, 80, 80, 8, 50, 80, 200, 50};      
   int nt = sizeof(espera)/sizeof(int);
   pthread_t hilo;
      
   if(argc < 2)
   {
      printf("proceso B con menos de 2 args\n");
      exit(1);
   }

   /* El argumento 1 es el nombre de la cola */
   
   cola = mq_open(argv[1], O_WRONLY, 0, NULL);
   printf("proceso b ha abierto la cola\n");

   /* Bloquear senal SIGRTMIN */
   
   sigemptyset(&set); sigaddset(&set, SIGRTMIN);
   sigprocmask(SIG_BLOCK, &set, NULL);
   
   /* Crear hilo de recepcion de senales */
   
   pthread_create(&hilo, NULL, recibe, NULL);
  
   /* Iteraciones para enviar datos por la cola utilizando un retraso variable */
    
   t.tv_sec = 0;    
   for(n = 0; n<nt; n++)
   {
      t.tv_nsec = espera[n]*1000000L;
      nanosleep(&t, NULL);
      if(n < nt-1) dato = ACTIVO;
      else            dato = FIN;
      printf("proceso B envia con %d ms de retraso\n",espera[n]); fflush(stdout);
      mq_send(cola, (unsigned char *)&dato, sizeof(int), 0);
   }
     
   printf("proceso B acabando correctamente\n");

   return 0;
}

/* Hilo de recepcion de senales */

void *recibe(void *p)
{
     sigset_t senal;
     
     sigemptyset(&senal); sigaddset(&senal, SIGRTMIN);
     
     while(1)
     {
         sigwaitinfo(&senal, NULL);
         printf("Hilo recibe: Recibida senal\n"); fflush(stdout);
     }
     return NULL;        
}
